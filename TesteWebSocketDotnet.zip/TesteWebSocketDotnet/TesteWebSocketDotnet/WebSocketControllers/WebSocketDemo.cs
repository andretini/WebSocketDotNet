﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Concurrent;
using System.Net.WebSockets;
using System.Text;
using System.Threading.Tasks;

namespace TesteWebSocketDotnet.Controllers
{
    [ApiController]
    [Route("api")]
    public class WebSocketController : ControllerBase
    {
        private static readonly ConcurrentDictionary<string, WebSocket> _sockets = new ConcurrentDictionary<string, WebSocket>();
        private static int _socketIdCounter = 0;

        [HttpGet("/ws/[controller]/connect")]
        public async Task<IActionResult> Connect()
        {
            if (HttpContext.WebSockets.IsWebSocketRequest)
            {
                WebSocket webSocket = await HttpContext.WebSockets.AcceptWebSocketAsync();
                string socketId = (_socketIdCounter++).ToString();
                _sockets.TryAdd(socketId, webSocket);

                await HandleWebSocketConnection(webSocket, socketId);

                return new EmptyResult();
            }
            else
            {
                return BadRequest("WebSocket connection required.");
            }
        }

        private async Task HandleWebSocketConnection(WebSocket webSocket, string socketId)
        {
            var buffer = new byte[1024 * 4];

            try
            {
                WebSocketReceiveResult result = await webSocket.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);

                while (!result.CloseStatus.HasValue)
                {
                    var receivedMessage = Encoding.UTF8.GetString(buffer, 0, result.Count);
                    Console.WriteLine($"Received message from {socketId}: {receivedMessage}");

                    // Broadcast the message to all connected clients
                    foreach (var kvp in _sockets)
                    {
                        if (kvp.Key != socketId) // Don't send the message back to the sender
                        {
                            WebSocket clientSocket = kvp.Value;
                            if (clientSocket.State == WebSocketState.Open)
                            {
                                var responseMessage = Encoding.UTF8.GetBytes(receivedMessage);
                                await clientSocket.SendAsync(new ArraySegment<byte>(responseMessage, 0, responseMessage.Length), result.MessageType, result.EndOfMessage, CancellationToken.None);
                            }
                        }
                    }

                    result = await webSocket.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in connection {socketId}: {ex.Message}");
            }
            finally
            {
                _sockets.TryRemove(socketId, out _);
                if (webSocket.State == WebSocketState.Open || webSocket.State == WebSocketState.CloseReceived)
                {
                    await webSocket.CloseAsync(WebSocketCloseStatus.NormalClosure, "Closing", CancellationToken.None);
                }
                webSocket.Dispose();
            }
        }

        [HttpGet("[action]")]
        public async Task BroadcastMessage(string message)
        {
            var buffer = Encoding.UTF8.GetBytes(message);

            foreach (var kvp in _sockets)
            {
                WebSocket clientSocket = kvp.Value;
                if (clientSocket.State == WebSocketState.Open)
                {
                    await clientSocket.SendAsync(new ArraySegment<byte>(buffer), WebSocketMessageType.Text, true, CancellationToken.None);
                }
            }
        }
    }

}
