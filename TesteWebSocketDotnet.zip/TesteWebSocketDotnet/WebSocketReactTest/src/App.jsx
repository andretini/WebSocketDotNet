import React, { useState, useEffect } from 'react';
import ProductList from './Components/ProductList';
import CreateProduct from './Components/ProductCreate';
import './App.css';

function App() {
  const [products, setProducts] = useState([]);

  // WebSocket reference
  const [webSocket, setWebSocket] = useState(null);

  useEffect(() => {
    // Connect to the WebSocket
    const socket = new WebSocket('wss://localhost:7020/ws/Product/Connect');

    socket.onopen = () => {
      console.log('WebSocket connected');
    };

    socket.onmessage = (message) => {
      if (message.data === 'RELOAD_ORDER') {
        // Reload product list when 'RELOAD_ORDER' is received
        fetchProducts();
      }
    };

    socket.onclose = () => {
      console.log('WebSocket disconnected');
    };

    setWebSocket(socket);

    // Cleanup the WebSocket connection when the component unmounts
    return () => {
      socket.close();
    };
  }, []);

  // Function to fetch the product list
  const fetchProducts = async () => {
    try {
      const response = await fetch('https://localhost:7020/api/products/List');
      const data = await response.json();
      setProducts(data);
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  };

  // Call fetchProducts initially
  useEffect(() => {
    fetchProducts();
  }, []);

  return (
    <div className="App">
      <h1>Product Management</h1>
      <CreateProduct />
      <ProductList products={products} />
    </div>
  );
}

export default App;
